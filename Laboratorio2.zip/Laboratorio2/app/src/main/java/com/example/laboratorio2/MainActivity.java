package com.example.laboratorio2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Gravity;

public class MainActivity extends AppCompatActivity {

    private RadioButton et1;
    private RadioButton et2;
    private RadioButton et3;
    private RadioButton et4;
    private RadioButton et5;
    private TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = findViewById(R.id.radioButton);
        et2 = findViewById(R.id.radioButton2);
        et3 = findViewById(R.id.radioButton3);
        et4 = findViewById(R.id.radioButton4);
        et5 = findViewById(R.id.radioButton5);
    }

    public void mostrar(View view) {
        String valor1 = et1.getText().toString();
        String valor2 = et2.getText().toString();
        String valor3 = et3.getText().toString();
        String valor4 = et4.getText().toString();
        String valor5 = et5.getText().toString();

        if (et1.isChecked()){
            showToast(valor1);
            et1.setChecked(false);
        }
        else if (et2.isChecked()){
            showToast(valor2);
            et2.setChecked(false);
        }
        else if (et3.isChecked()){
            showToast(valor3);
            et3.setChecked(false);

        }
        else if (et4.isChecked()){
            showToast(valor4);
            et4.setChecked(false);

        }
        else if (et5.isChecked()){

            showToast(valor5);
            et5.setChecked(false);

        }
    }
    private void showToast(String message) {
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 50, 100);
        toast.show();
    }
}